import Layout from "../components/LayoutSetting";

const setting = () => {
  return (
    <>
      <Layout></Layout>;
    </>
  );
};
export default setting;
